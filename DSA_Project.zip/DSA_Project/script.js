// ==========================
// APPLICATION STATE
// ==========================
let notesData = [];
let currentDate = new Date();
let calendarDate = new Date();
let popupCalendarDate = new Date();
let currentPage = 'home';
let isDarkTheme = false;

// Mood mapping
const moodMap = {
  "😊": "Happy",
  "🙂": "Content",
  "😐": "Neutral",
  "🙁": "Sad",
  "😣": "Stressed"
};

// API Base URL
const API_BASE = 'http://127.0.0.1:5000/api';

// ==========================
// ACHIEVEMENTS SYSTEM
// ==========================
const achievements = {
  achievements: {
    firstNote: { 
      unlocked: false, 
      title: "First Steps", 
      desc: "Write your first journal entry",
      icon: "📝",
      points: 10
    },
    fiveNotes: { 
      unlocked: false, 
      title: "Consistent Writer", 
      desc: "Write 5 journal entries",
      icon: "✍️",
      points: 20
    },
    moodMaster: { 
      unlocked: false, 
      title: "Mood Master", 
      desc: "Use all 5 different moods",
      icon: "😊",
      points: 15
    },
    weekStreak: { 
      unlocked: false, 
      title: "Dedicated", 
      desc: "Write for 7 days in a row",
      icon: "🔥",
      points: 30
    },
    photoFan: { 
      unlocked: false, 
      title: "Photo Fan", 
      desc: "Add photos to 3 different notes",
      icon: "📷",
      points: 15
    },
    earlyBird: { 
      unlocked: false, 
      title: "Early Bird", 
      desc: "Write a note before 8 AM",
      icon: "🌅",
      points: 10
    },
    nightOwl: { 
      unlocked: false, 
      title: "Night Owl", 
      desc: "Write a note after 10 PM",
      icon: "🌙",
      points: 10
    }
  },

  userStats: {
    totalNotes: 0,
    uniqueMoods: new Set(),
    notesWithPhotos: 0,
    earlyNotes: 0,
    lateNotes: 0
  },

  init() {
    this.loadProgress();
  },

  loadProgress() {
    const saved = localStorage.getItem('journal-achievements');
    if (saved) {
      const data = JSON.parse(saved);
      this.achievements = { ...this.achievements, ...data.achievements };
      this.userStats = { ...this.userStats, ...data.userStats };
      if (data.userStats.uniqueMoods) {
        this.userStats.uniqueMoods = new Set(data.userStats.uniqueMoods);
      }
    }
  },

  saveProgress() {
    const data = {
      achievements: this.achievements,
      userStats: {
        ...this.userStats,
        uniqueMoods: Array.from(this.userStats.uniqueMoods)
      }
    };
    localStorage.setItem('journal-achievements', JSON.stringify(data));
  },

  checkAchievements() {
    const unlocked = [];

    // First Note
    if (this.userStats.totalNotes >= 1 && !this.achievements.firstNote.unlocked) {
      this.achievements.firstNote.unlocked = true;
      unlocked.push(this.achievements.firstNote);
    }

    // Five Notes
    if (this.userStats.totalNotes >= 5 && !this.achievements.fiveNotes.unlocked) {
      this.achievements.fiveNotes.unlocked = true;
      unlocked.push(this.achievements.fiveNotes);
    }

    // Mood Master
    if (this.userStats.uniqueMoods.size >= 5 && !this.achievements.moodMaster.unlocked) {
      this.achievements.moodMaster.unlocked = true;
      unlocked.push(this.achievements.moodMaster);
    }

    // Photo Fan
    if (this.userStats.notesWithPhotos >= 3 && !this.achievements.photoFan.unlocked) {
      this.achievements.photoFan.unlocked = true;
      unlocked.push(this.achievements.photoFan);
    }

    // Early Bird
    if (this.userStats.earlyNotes >= 1 && !this.achievements.earlyBird.unlocked) {
      this.achievements.earlyBird.unlocked = true;
      unlocked.push(this.achievements.earlyBird);
    }

    // Night Owl
    if (this.userStats.lateNotes >= 1 && !this.achievements.nightOwl.unlocked) {
      this.achievements.nightOwl.unlocked = true;
      unlocked.push(this.achievements.nightOwl);
    }

    // Show popup for new achievements
    unlocked.forEach(achievement => {
      this.showAchievementPopup(achievement);
    });

    this.saveProgress();
    return unlocked;
  },

  showAchievementPopup(achievement) {
    const popup = document.createElement('div');
    popup.className = 'achievement-popup';
    popup.innerHTML = `
      <div class="achievement-popup-content">
        <div class="achievement-icon">${achievement.icon}</div>
        <div class="achievement-text">
          <div class="achievement-title">Achievement Unlocked!</div>
          <div class="achievement-name">${achievement.title}</div>
          <div class="achievement-desc">${achievement.desc}</div>
          <div class="achievement-points">+${achievement.points} points</div>
        </div>
      </div>
    `;

    document.body.appendChild(popup);

    // Add animation class
    setTimeout(() => {
      popup.classList.add('show');
    }, 100);

    // Remove after 4 seconds
    setTimeout(() => {
      popup.classList.remove('show');
      setTimeout(() => {
        if (popup.parentNode) {
          popup.parentNode.removeChild(popup);
        }
      }, 300);
    }, 4000);
  },

  onNoteSaved(note) {
    // Update stats
    this.userStats.totalNotes++;
    
    // Track unique moods
    this.userStats.uniqueMoods.add(note.mood);
    
    // Track photos
    if (note.photos && note.photos.length > 0) {
      this.userStats.notesWithPhotos++;
    }
    
    // Track time of day
    const noteDate = new Date(note.date);
    const hour = noteDate.getHours();
    
    if (hour < 8) {
      this.userStats.earlyNotes++;
    }
    
    if (hour >= 22) {
      this.userStats.lateNotes++;
    }
    
    // Check for new achievements
    this.checkAchievements();
    this.saveProgress();
  },

  getTotalPoints() {
    return Object.values(this.achievements)
      .filter(ach => ach.unlocked)
      .reduce((total, ach) => total + ach.points, 0);
  },

  getUnlockedCount() {
    return Object.values(this.achievements).filter(ach => ach.unlocked).length;
  }
};

// ==========================
// WRITING STREAK SYSTEM
// ==========================
const streakManager = {
  currentStreak: 0,
  longestStreak: 0,
  lastEntryDate: null,

  init() {
    this.loadStreakData();
    this.updateStreakDisplay();
  },

  loadStreakData() {
    const saved = localStorage.getItem('journal-streak');
    if (saved) {
      const data = JSON.parse(saved);
      this.currentStreak = data.currentStreak || 0;
      this.longestStreak = data.longestStreak || 0;
      this.lastEntryDate = data.lastEntryDate ? new Date(data.lastEntryDate) : null;
    }
  },

  saveStreakData() {
    const data = {
      currentStreak: this.currentStreak,
      longestStreak: this.longestStreak,
      lastEntryDate: this.lastEntryDate
    };
    localStorage.setItem('journal-streak', JSON.stringify(data));
  },

  onNoteSaved(note) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const noteDate = new Date(note.date);
    noteDate.setHours(0, 0, 0, 0);

    // If this is the first note ever
    if (!this.lastEntryDate) {
      this.currentStreak = 1;
      this.longestStreak = 1;
      this.lastEntryDate = noteDate;
      this.saveStreakData();
      this.updateStreakDisplay();
      return;
    }

    const lastEntry = new Date(this.lastEntryDate);
    lastEntry.setHours(0, 0, 0, 0);

    const dayDiff = Math.floor((noteDate - lastEntry) / (1000 * 60 * 60 * 24));

    if (dayDiff === 0) {
      // Same day, no change to streak
      return;
    } else if (dayDiff === 1) {
      // Consecutive day - increase streak
      this.currentStreak++;
    } else if (dayDiff > 1) {
      // Streak broken - reset to 1
      this.currentStreak = 1;
    }

    // Update longest streak if needed
    if (this.currentStreak > this.longestStreak) {
      this.longestStreak = this.currentStreak;
    }

    this.lastEntryDate = noteDate;
    this.saveStreakData();
    this.updateStreakDisplay();

    // Check for week streak achievement
    if (this.currentStreak >= 7 && !achievements.achievements.weekStreak.unlocked) {
      achievements.achievements.weekStreak.unlocked = true;
      achievements.showAchievementPopup(achievements.achievements.weekStreak);
      achievements.saveProgress();
    }
  },

  updateStreakDisplay() {
    // Update any streak displays in the UI
    const streakElement = document.getElementById('currentStreak');
    if (streakElement) {
      streakElement.textContent = this.currentStreak;
    }

    const longestElement = document.getElementById('longestStreak');
    if (longestElement) {
      longestElement.textContent = this.longestStreak;
    }

    const streakEmoji = document.getElementById('streakEmoji');
    if (streakEmoji) {
      streakEmoji.textContent = this.getStreakEmoji();
    }

    const streakMessage = document.getElementById('streakMessage');
    if (streakMessage) {
      streakMessage.textContent = this.getMotivationalMessage();
    }
  },

  getMotivationalMessage() {
    if (this.currentStreak === 0) {
      return "Start your journaling journey today! ✨";
    } else if (this.currentStreak === 1) {
      return "Great start! Come back tomorrow to build your streak! 🌟";
    } else if (this.currentStreak < 7) {
      return `🔥 ${this.currentStreak} day streak! You're doing amazing!`;
    } else if (this.currentStreak < 30) {
      return `🔥 ${this.currentStreak} day streak! You're unstoppable!`;
    } else {
      return `🔥 ${this.currentStreak} day streak! Legendary! 🏆`;
    }
  },

  getStreakEmoji() {
    if (this.currentStreak >= 30) return "🏆";
    if (this.currentStreak >= 14) return "⚡";
    if (this.currentStreak >= 7) return "🔥";
    if (this.currentStreak >= 3) return "🌟";
    return "✨";
  }
};

// ==========================
// INITIALIZATION
// ==========================
document.addEventListener('DOMContentLoaded', () => {
  initializeTheme();
  initializeNavigation();
  initializeHomePage();
  initializeNotePopup();
  initializeGallery();
  initializeCalendar();
  initializeFAB();
  initializeKeyboardShortcuts();
  initializeContextMenu();
  initializeTrashBin();
  initializeDeveloperModal();
  
  // Initialize achievements and streak systems
  achievements.init();
  streakManager.init();

  // Update the no entries icon on initial load
  updateNoEntriesIcon();
  
  // Show home page by default
  showPage('home');
});

// ==========================
// THEME MANAGEMENT
// ==========================
function initializeTheme() {
  const themeToggle = document.getElementById('themeToggle');
  const savedTheme = localStorage.getItem('journal-theme');
  
  if (savedTheme === 'dark') {
    enableDarkTheme();
  } else {
    enableLightTheme();
  }
  
  themeToggle.addEventListener('click', () => {
    if (isDarkTheme) {
      enableLightTheme();
    } else {
      enableDarkTheme();
    }
  });
}

function enableDarkTheme() {
  document.documentElement.setAttribute('data-theme', 'dark');
  document.getElementById('themeToggle').textContent = '☀️';
  isDarkTheme = true;
  localStorage.setItem('journal-theme', 'dark');
  updateNoEntriesIcon(); // Update the icon when theme changes
}

function enableLightTheme() {
  document.documentElement.setAttribute('data-theme', 'light');
  document.getElementById('themeToggle').textContent = '🌙';
  isDarkTheme = false;
  localStorage.setItem('journal-theme', 'light');
  updateNoEntriesIcon(); // Update the icon when theme changes
}

// This is now handled by CSS, but we can keep the function for any future logic
function updateNoEntriesIcon() {
  // No additional logic needed as CSS handles icon visibility based on theme
}

// ==========================
// FLOATING ACTION BUTTON
// ==========================
function initializeFAB() {
  const fabMain = document.getElementById('fabMain');
  const fabOptions = document.querySelector('.fab-options');
  const addNoteBtn = document.getElementById('addNoteBtn');
  
  fabMain.addEventListener('click', () => {
    fabOptions.classList.toggle('active');
    fabMain.classList.toggle('active');
  });
  
  // FAB options
  document.querySelectorAll('.fab-option').forEach(option => {
    option.addEventListener('click', (e) => {
      e.stopPropagation();
      const action = option.getAttribute('data-action');
      
      switch (action) {
        case 'text-note':
          addNoteBtn.click();
          break;
        case 'photo-note':
          addNoteBtn.click();
          setTimeout(() => {
            document.getElementById('takePhotoBtn').click();
          }, 100);
          break;
        case 'voice-note':
          // Placeholder for voice note functionality
          showSuccessMessage('Voice notes coming soon!');
          break;
      }
      
      fabOptions.classList.remove('active');
      fabMain.classList.remove('active');
    });
  });
  
  // Close FAB when clicking outside
  document.addEventListener('click', (e) => {
    if (!fabMain.contains(e.target) && !fabOptions.contains(e.target)) {
      fabOptions.classList.remove('active');
      fabMain.classList.remove('active');
    }
  });
}

// ==========================
// KEYBOARD SHORTCUTS
// ==========================
function initializeKeyboardShortcuts() {
  document.addEventListener('keydown', (e) => {
    // Ctrl/Cmd + N for new note
    if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
      e.preventDefault();
      document.getElementById('addNoteBtn').click();
    }
    
    // Escape to close modals
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal, .overlay').forEach(el => {
        el.style.display = 'none';
        el.classList.remove('active');
      });
      document.querySelector('.fab-options').classList.remove('active');
    }
    
    // Number keys for quick mood selection (when popup is open)
    // if (document.getElementById('overlay').classList.contains('active')) {
      // switch (e.key) {
        // case '1': selectMoodByIndex(0); break;
        // case '2': selectMoodByIndex(1); break;
        // case '3': selectMoodByIndex(2); break;
        // case '4': selectMoodByIndex(3); break;
        // case '5': selectMoodByIndex(4); break;
      // }
    // }
  });
}

function selectMoodByIndex(index) {
  const emojis = document.querySelectorAll('.emojis span');
  if (emojis[index]) {
    emojis[index].click();
  }
}

// ==========================
// CONTEXT MENU
// ==========================
function initializeContextMenu() {
  const contextMenu = document.getElementById('contextMenu');
  
  document.addEventListener('contextmenu', (e) => {
    if (e.target.closest('.note-card')) {
      e.preventDefault();
      const noteCard = e.target.closest('.note-card');
      const noteId = noteCard.querySelector('.delete-note-btn')?.getAttribute('data-note-id');
      
      if (noteId) {
        contextMenu.style.display = 'block';
        contextMenu.style.left = `${e.pageX}px`;
        contextMenu.style.top = `${e.pageY}px`;
        
        // Store note ID for context actions
        contextMenu.setAttribute('data-note-id', noteId);
      }
    }
  });
  
  document.addEventListener('click', () => {
    contextMenu.style.display = 'none';
  });
  
  // Context menu actions
  document.querySelectorAll('.context-item').forEach(item => {
    item.addEventListener('click', (e) => {
      const action = item.getAttribute('data-action');
      const noteId = contextMenu.getAttribute('data-note-id');
      
      switch (action) {
        case 'delete':
          deleteNoteById(noteId);
          break;
        case 'share':
          shareNoteById(noteId);
          break;
        case 'edit':
          editNoteById(noteId);
          break;
      }
      
      contextMenu.style.display = 'none';
    });
  });
}

async function deleteNoteById(noteId) {
  if (confirm('Are you sure you want to delete this note?')) {
    try {
      await deleteNote(noteId);
      showSuccessMessage('Note moved to trash!');
      renderNotesForDate(currentDate);
    } catch (error) {
      alert('Failed to delete note. Please try again.');
    }
  }
}

function shareNoteById(noteId) {
  // Placeholder for share functionality
  showSuccessMessage('Share functionality coming soon!');
}

function editNoteById(noteId) {
  // Placeholder for edit functionality
  showSuccessMessage('Edit functionality coming soon!');
}

// ==========================
// API FUNCTIONS
// ==========================
async function fetchNotes(date = null) {
  try {
    let url = `${API_BASE}/notes`;
    if (date) {
      // Ensure date is in YYYY-MM-DD format
      const dateObj = new Date(date);
      const formattedDate = formatDateForAPI(dateObj);
      url = `${API_BASE}/notes?date=${formattedDate}`;
    }
    
    const response = await fetch(url);
    if (!response.ok) throw new Error('Failed to fetch notes');
    const notes = await response.json();
    
    // Filter out deleted notes for normal display
    return notes.filter(note => !note.deleted);
  } catch (error) {
    console.error('Error fetching notes:', error);
    return [];
  }
}

async function saveNote(note) {
  try {
    const response = await fetch(`${API_BASE}/notes`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(note)
    });
    
    if (!response.ok) throw new Error('Failed to save note');
    return await response.json();
  } catch (error) {
    console.error('Error saving note:', error);
    throw error;
  }
}

async function deleteNote(noteId) {
  try {
    const response = await fetch(`${API_BASE}/notes/${noteId}`, {
      method: 'DELETE'
    });
    
    if (!response.ok) throw new Error('Failed to delete note');
    return await response.json();
  } catch (error) {
    console.error('Error deleting note:', error);
    throw error;
  }
}

async function fetchPhotos(dateFilter = 'all', moodFilter = 'all') {
  try {
    const response = await fetch(`${API_BASE}/photos?date_filter=${dateFilter}&mood_filter=${moodFilter}`);
    if (!response.ok) throw new Error('Failed to fetch photos');
    const photos = await response.json();
    return photos.filter(photo => !photo.deleted);
  } catch (error) {
    console.error('Error fetching photos:', error);
    return [];
  }
}

// ==========================
// UTILITY FUNCTIONS
// ==========================
function formatDateForAPI(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function areDatesEqual(date1, date2) {
  return formatDateForAPI(date1) === formatDateForAPI(date2);
}

// ==========================
// NAVIGATION MANAGEMENT
// ==========================
function initializeNavigation() {
  const navLinks = document.querySelectorAll('.nav-link');
  
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const page = link.getAttribute('data-page');
      showPage(page);
      
      // Update active state
      navLinks.forEach(l => l.classList.remove('active'));
      link.classList.add('active');
    });
  });
}

function showPage(page) {
  // Hide all pages
  document.querySelectorAll('.page').forEach(p => {
    p.classList.remove('active');
  });
  
  // Show selected page
  document.getElementById(`${page}-page`).classList.add('active');
  currentPage = page;
  
  // Refresh page content
  if (page === 'home') {
    updateDateDisplay();
    renderNotesForDate(currentDate);
  } else if (page === 'gallery') {
    gallery.renderGallery();
  } else if (page === 'calendar') {
    calendar.renderCalendar();
  } else if (page === 'achievements') {
    renderAchievementsPage();
  } else if (page === 'trash') {
    trashBin.renderTrash();
  }
}

// ==========================
// HOME PAGE FUNCTIONALITY
// ==========================
function initializeHomePage() {
  const dateElement = document.getElementById('current-date');
  const nextArrow = document.getElementById('next');
  const prevArrow = document.getElementById('prev');
  const calendarPopup = document.getElementById('calendar-popup');
  const calendarMonthYear = document.getElementById('calendar-month-year');
  const calendarGrid = document.getElementById('calendar-grid');
  const prevMonthBtn = document.getElementById('prev-month');
  const nextMonthBtn = document.getElementById('next-month');

  // Initialize date display
  updateDateDisplay();
  generateCalendar(calendarDate);

  // Arrow navigation
  prevArrow.addEventListener('click', () => {
    currentDate.setDate(currentDate.getDate() - 1);
    updateDateDisplay();
  });

  nextArrow.addEventListener('click', () => {
    currentDate.setDate(currentDate.getDate() + 1);
    updateDateDisplay();
  });

  // Calendar popup
  dateElement.addEventListener('click', () => {
    calendarPopup.classList.toggle('active');
  });

  // Calendar navigation
  prevMonthBtn.addEventListener('click', () => {
    calendarDate.setMonth(calendarDate.getMonth() - 1);
    generateCalendar(calendarDate);
  });

  nextMonthBtn.addEventListener('click', () => {
    calendarDate.setMonth(calendarDate.getMonth() + 1);
    generateCalendar(calendarDate);
  });

  // Hide popup when clicking outside
  document.addEventListener('click', (e) => {
    if (!calendarPopup.contains(e.target) && e.target !== dateElement) {
      calendarPopup.classList.remove('active');
    }
  });
}

function updateDateDisplay() {
  const dateElement = document.getElementById('current-date');
  const nextArrow = document.getElementById('next');
  const prevArrow = document.getElementById('prev');
  const options = { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' };
  
  const formattedDate = currentDate.toLocaleDateString('en-US', options);
  dateElement.textContent = formattedDate;

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const currentDateCopy = new Date(currentDate);
  currentDateCopy.setHours(0, 0, 0, 0);
  
  nextArrow.classList.toggle('disabled', currentDateCopy.getTime() === today.getTime());
  
  renderNotesForDate(currentDate);
}

function generateCalendar(date) {
  const calendarMonthYear = document.getElementById('calendar-month-year');
  const calendarGrid = document.getElementById('calendar-grid');
  const prevMonthBtn = document.getElementById('prev-month');
  const nextMonthBtn = document.getElementById('next-month');
  
  const year = date.getFullYear();
  const month = date.getMonth();
  
  // Update calendar header
  calendarMonthYear.textContent = date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  
  // Clear previous calendar
  calendarGrid.innerHTML = '';
  
  // Add day headers
  const daysOfWeek = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
  daysOfWeek.forEach(day => {
    const dayElement = document.createElement('div');
    dayElement.className = 'calendar-day';
    dayElement.textContent = day;
    calendarGrid.appendChild(dayElement);
  });
  
  // Get first day of month and number of days
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const daysInMonth = lastDay.getDate();
  const startingDay = firstDay.getDay();
  
  // Add empty cells for days before the first day of the month
  for (let i = 0; i < startingDay; i++) {
    const emptyCell = document.createElement('div');
    emptyCell.className = 'calendar-date other-month';
    calendarGrid.appendChild(emptyCell);
  }
  
  // Add days of the month
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  for (let day = 1; day <= daysInMonth; day++) {
    const dateCell = document.createElement('div');
    dateCell.className = 'calendar-date';
    dateCell.textContent = day;
    
    const cellDate = new Date(year, month, day);
    cellDate.setHours(0, 0, 0, 0);
    
    // Disable future dates (opposite of note calendar)
    if (cellDate.getTime() > today.getTime()) {
      dateCell.classList.add('future-date');
    }
    
    if (cellDate.getTime() === today.getTime()) {
      dateCell.classList.add('selected');
      dateCell.classList.add('today');
    }
    
    // Check if this date has notes (only for past and current dates)
    if (cellDate.getTime() <= today.getTime()) {
      checkDateHasNotes(cellDate).then(hasNotes => {
        if (hasNotes) {
          dateCell.classList.add('has-notes');
        }
      });
    }
    
    // Only allow clicking on past and current dates
    if (cellDate.getTime() <= today.getTime()) {
      dateCell.addEventListener('click', () => {
        currentDate = new Date(year, month, day);
        updateDateDisplay();
        document.getElementById('calendar-popup').classList.remove('active');
      });
    }
    
    calendarGrid.appendChild(dateCell);
  }
  
  // Update navigation buttons - disable next month if it's in the future
  const nextMonth = new Date(year, month + 1, 1);
  nextMonth.setHours(0, 0, 0, 0);
  
  if (nextMonth.getTime() > today.getTime()) {
    nextMonthBtn.classList.add('disabled');
    nextMonthBtn.style.opacity = '0.5';
    nextMonthBtn.style.pointerEvents = 'none';
  } else {
    nextMonthBtn.classList.remove('disabled');
    nextMonthBtn.style.opacity = '1';
    nextMonthBtn.style.pointerEvents = 'auto';
  }
  
  // Enable previous month button always (since past months are accessible)
  prevMonthBtn.classList.remove('disabled');
  prevMonthBtn.style.opacity = '1';
  prevMonthBtn.style.pointerEvents = 'auto';
}

async function checkDateHasNotes(date) {
  try {
    const dateString = formatDateForAPI(date);
    const notes = await fetchNotes(dateString);
    return notes.length > 0;
  } catch (error) {
    return false;
  }
}

async function renderNotesForDate(date) {
  const container = document.getElementById('savedNotesContainer');
  const noEntries = document.getElementById('noEntries');
  const skeletonContainer = document.getElementById('skeletonContainer');
  
  // Show skeleton loading
  container.innerHTML = '';
  noEntries.style.display = 'none';
  skeletonContainer.style.display = 'block';
  
  try {
    // Fetch notes for the selected date from backend
    const dateString = formatDateForAPI(date);
    const dayNotes = await fetchNotes(dateString);
    
    // Hide skeleton
    skeletonContainer.style.display = 'none';
    
    if (dayNotes.length === 0) {
      container.innerHTML = '';
      noEntries.style.display = 'block';
      return;
    }
    
    noEntries.style.display = 'none';
    container.innerHTML = '';
    
    // Sort notes by time (newest first)
    dayNotes.sort((a, b) => new Date(b.date) - new Date(a.date));
    
    // Create note cards with animation
    dayNotes.forEach((note, index) => {
      setTimeout(() => {
        const noteCard = createNoteCard(note);
        container.appendChild(noteCard);
        
        // Add appear animation
        setTimeout(() => {
          noteCard.classList.add('appear');
        }, 50);
      }, index * 100); // Stagger animation
    });
    
  } catch (error) {
    console.error('Error rendering notes:', error);
    skeletonContainer.style.display = 'none';
    container.innerHTML = '<div style="color: #ff6b6b; text-align: center; padding: 20px;">Error loading notes</div>';
  }
}

function createNoteCard(note) {
  const noteCard = document.createElement('div');
  noteCard.className = 'note-card';
  
  const noteDate = new Date(note.date);
  const timeString = noteDate.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
  
  noteCard.innerHTML = `
    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px;">
      <div style="display: flex; align-items: center; gap: 10px;">
        <span style="font-size: 30px;">${note.mood}</span>
        <span style="font-size: 18px; color: var(--accent-light);">${moodMap[note.mood]}</span>
      </div>
      <button class="delete-note-btn" data-note-id="${note.id}" style="background: #ff4d4d; color: white; border: none; border-radius: 5px; padding: 5px 10px; cursor: pointer; font-size: 12px; transition: all 0.2s ease;">Delete</button>
    </div>
    ${note.title ? `<div style="font-size: 20px; font-weight: bold; margin-bottom: 10px; color: var(--accent-light);">${note.title}</div>` : ''}
    <div style="color: #ccc; margin-bottom: 15px;">${timeString}</div>
    <div style="line-height: 1.5; margin-bottom: 15px;">${note.text}</div>
    ${note.photos && note.photos.length > 0 ? `
      <div style="display: flex; gap: 10px; flex-wrap: wrap;">
        ${note.photos.map(photo => `
          <img src="${photo}" style="width: 80px; height: 80px; object-fit: cover; border-radius: 8px; border: 2px solid #555; cursor: pointer; transition: all 0.2s ease;" 
               onclick="gallery.openPhotoModal('${photo}', '${note.mood}', '${note.date}', '${note.text.replace(/'/g, "\\'")}')">
        `).join('')}
      </div>
    ` : ''}
  `;
  
  // Add delete event listener
  const deleteBtn = noteCard.querySelector('.delete-note-btn');
  deleteBtn.addEventListener('click', async (e) => {
    e.stopPropagation();
    if (confirm('Are you sure you want to delete this note?')) {
      try {
        await deleteNote(note.id);
        showSuccessMessage('Note moved to trash!');
        renderNotesForDate(currentDate); // Refresh the display
      } catch (error) {
        alert('Failed to delete note. Please try again.');
      }
    }
  });
  
  return noteCard;
}

// ==========================
// NOTE POPUP FUNCTIONALITY
// ==========================
function initializeNotePopup() {
  const addNoteBtn = document.getElementById('addNoteBtn');
  const overlay = document.getElementById('overlay');
  const closeNoteBtn = document.getElementById('closeNote');
  const saveNoteBtn = document.getElementById('saveNote');
  const moodSelector = document.getElementById('moodSelector');
  const moodPopup = document.getElementById('moodPopup');
  const emojis = moodPopup.querySelectorAll('.emojis span');
  const moodIcon = document.getElementById('moodIcon');
  const moodText = document.getElementById('moodText');
  const noteTitle = document.getElementById('noteTitle');
  const noteDate = document.getElementById('noteDate');
  const noteTime = document.getElementById('noteTime');
  const datePickerBtn = document.getElementById('datePickerBtn');
  const popupCalendar = document.getElementById('calendarPopup');
  const popupCalendarMonthYear = document.getElementById('popupCalendarMonthYear');
  const popupCalendarGrid = document.getElementById('popupCalendarGrid');
  const popupPrevMonthBtn = document.getElementById('popupPrevMonth');
  const popupNextMonthBtn = document.getElementById('popupNextMonth');
  const takePhotoBtn = document.getElementById('takePhotoBtn');
  const fromDeviceBtn = document.getElementById('fromDeviceBtn');
  const noteTextarea = document.getElementById('noteTextarea');
  const photoPreviewContainer = document.getElementById('photoPreviewContainer');

  let currentPhotos = [];

  // Open note popup
  addNoteBtn.addEventListener('click', () => {
    // Reset form
    moodIcon.textContent = '😊';
    moodText.textContent = 'Happy';
    noteTitle.value = '';
    noteTextarea.value = '';
    currentPhotos = [];
    photoPreviewContainer.innerHTML = '';
    
    // Set current date and time
    updatePopupDateTime();
    
    // Show overlay
    overlay.classList.add('active');
  });

  // Close note popup
  closeNoteBtn.addEventListener('click', () => {
    overlay.classList.remove('active');
  });

  // Save note - FIXED DATE HANDLING
  saveNoteBtn.addEventListener('click', async () => {
      const noteText = noteTextarea.value.trim();
      const noteTitleValue = noteTitle.value.trim();
      
      if (!noteText) {
        alert('Please write something in your note');
        return;
      }

      // Use the selected date from popupCalendarDate
      const selectedDate = new Date(popupCalendarDate);
      const now = new Date();
      
      // Set the time to current time but keep the selected date
      selectedDate.setHours(now.getHours(), now.getMinutes(), now.getSeconds(), now.getMilliseconds());
      
      // Format date for backend - use ISO string but ensure it represents the correct local date
      const year = selectedDate.getFullYear();
      const month = String(selectedDate.getMonth() + 1).padStart(2, '0');
      const day = String(selectedDate.getDate()).padStart(2, '0');
      const hours = String(selectedDate.getHours()).padStart(2, '0');
      const minutes = String(selectedDate.getMinutes()).padStart(2, '0');
      const seconds = String(selectedDate.getSeconds()).padStart(2, '0');
      
      // Create ISO string in local timezone
      const localISODate = `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
      
      const note = {
          mood: moodIcon.textContent,
          date: localISODate,
          title: noteTitleValue || '', // Add title field
          text: noteText,
          photos: [...currentPhotos],
          deleted: false // Add deleted flag
      };

      try {
          const savedNote = await saveNote(note);
          showSuccessMessage('Note saved successfully!');
          overlay.classList.remove('active');
          
          // Update achievements and streak
          achievements.onNoteSaved(note);
          streakManager.onNoteSaved(note);
          
          // Refresh display if on home page and the saved note is for the current date
          if (currentPage === 'home') {
            const noteDateObj = new Date(localISODate);
            if (areDatesEqual(noteDateObj, currentDate)) {
              renderNotesForDate(currentDate);
            }
          }
      } catch (error) {
        console.error('Save note error:', error);
        alert('Failed to save note. Please try again.');
      }
  });

  // Mood selection
  moodSelector.addEventListener('click', (e) => {
  e.stopPropagation();
  moodPopup.classList.toggle('active');
});

  // In the note popup initialization section, replace the emoji click event:
    emojis.forEach(emoji => {
     emoji.addEventListener('click', (e) => {
    e.stopPropagation(); // Prevent event from bubbling up
    moodIcon.textContent = emoji.textContent;
    moodText.textContent = moodMap[emoji.textContent];
    moodPopup.classList.remove('active'); // Auto-close after selection
  });
});

  // Date picker
  datePickerBtn.addEventListener('click', () => {
    popupCalendar.classList.toggle('active');
    datePickerBtn.classList.toggle('active');
    generatePopupCalendar(popupCalendarDate);
  });

  // Popup calendar navigation
  popupPrevMonthBtn.addEventListener('click', () => {
    popupCalendarDate.setMonth(popupCalendarDate.getMonth() - 1);
    generatePopupCalendar(popupCalendarDate);
  });

  popupNextMonthBtn.addEventListener('click', () => {
    popupCalendarDate.setMonth(popupCalendarDate.getMonth() + 1);
    generatePopupCalendar(popupCalendarDate);
  });

  // Photo handling
  takePhotoBtn.addEventListener('click', async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        alert('Camera access is not supported in your browser. Please use the file upload instead.');
        return;
      }
      
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' },
        audio: false 
      });
      
      const cameraModal = document.createElement('div');
      cameraModal.style.position = 'fixed';
      cameraModal.style.top = '0';
      cameraModal.style.left = '0';
      cameraModal.style.width = '100%';
      cameraModal.style.height = '100%';
      cameraModal.style.backgroundColor = 'rgba(0,0,0,0.9)';
      cameraModal.style.zIndex = '10000';
      cameraModal.style.display = 'flex';
      cameraModal.style.flexDirection = 'column';
      cameraModal.style.alignItems = 'center';
      cameraModal.style.justifyContent = 'center';
      
      const video = document.createElement('video');
      video.style.width = '100%';
      video.style.maxWidth = '500px';
      video.style.borderRadius = '10px';
      video.autoplay = true;
      video.srcObject = stream;
      
      const buttonContainer = document.createElement('div');
      buttonContainer.style.marginTop = '20px';
      buttonContainer.style.display = 'flex';
      buttonContainer.style.gap = '20px';
      
      const captureBtn = document.createElement('button');
      captureBtn.textContent = '📸 Capture';
      captureBtn.style.padding = '10px 20px';
      captureBtn.style.background = '#6b8c74';
      captureBtn.style.color = 'white';
      captureBtn.style.border = 'none';
      captureBtn.style.borderRadius = '5px';
      captureBtn.style.cursor = 'pointer';
      captureBtn.style.fontSize = '16px';
      
      const cancelBtn = document.createElement('button');
      cancelBtn.textContent = '❌ Cancel';
      cancelBtn.style.padding = '10px 20px';
      cancelBtn.style.background = '#ff4d4d';
      cancelBtn.style.color = 'white';
      cancelBtn.style.border = 'none';
      cancelBtn.style.borderRadius = '5px';
      cancelBtn.style.cursor = 'pointer';
      cancelBtn.style.fontSize = '16px';
      
      buttonContainer.appendChild(captureBtn);
      buttonContainer.appendChild(cancelBtn);
      
      cameraModal.appendChild(video);
      cameraModal.appendChild(buttonContainer);
      document.body.appendChild(cameraModal);
      
      // Capture photo
      captureBtn.addEventListener('click', () => {
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        const photoData = canvas.toDataURL('image/jpeg');
        currentPhotos.push(photoData);
        
        const photoItem = document.createElement('div');
        photoItem.className = 'photo-item';
        photoItem.style.position = 'relative';
        photoItem.style.display = 'inline-block';
        photoItem.style.margin = '5px';
        
        photoItem.innerHTML = `
          <img src="${photoData}" style="width: 80px; height: 80px; object-fit: cover; border-radius: 8px; border: 2px solid white;">
          <button class="removePhotoBtn" style="position: absolute; top: -5px; right: -5px; background: #ff4d4d; color: white; border: none; border-radius: 50%; width: 20px; height: 20px; font-size: 12px; cursor: pointer;">×</button>
        `;
        
        photoPreviewContainer.appendChild(photoItem);
        
        const removeBtn = photoItem.querySelector('.removePhotoBtn');
        removeBtn.addEventListener('click', () => {
          const index = currentPhotos.indexOf(photoData);
          if (index > -1) {
            currentPhotos.splice(index, 1);
          }
          photoItem.remove();
        });
        
        stream.getTracks().forEach(track => track.stop());
        document.body.removeChild(cameraModal);
      });
      
      cancelBtn.addEventListener('click', () => {
        stream.getTracks().forEach(track => track.stop());
        document.body.removeChild(cameraModal);
      });
      
    } catch (error) {
      console.error('Error accessing camera:', error);
      alert('Could not access camera. Please check permissions or use file upload.');
      
      const cameraInput = document.createElement('input');
      cameraInput.type = 'file';
      cameraInput.accept = 'image/*';
      cameraInput.capture = 'environment';
      cameraInput.style.display = 'none';
      
      cameraInput.addEventListener('change', function(e) {
        handlePhotoSelection(e);
        document.body.removeChild(cameraInput);
      });
      
      document.body.appendChild(cameraInput);
      cameraInput.click();
    }
  });

  fromDeviceBtn.addEventListener('click', () => {
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = 'image/*';
    fileInput.multiple = true;
    fileInput.style.display = 'none';
    
    fileInput.addEventListener('change', function(e) {
      handlePhotoSelection(e);
      document.body.removeChild(fileInput);
    });
    
    document.body.appendChild(fileInput);
    fileInput.click();
  });

  function handlePhotoSelection(e) {
    const files = e.target.files;
    
    if (!files || files.length === 0) return;
    
    for (let file of files) {
      const reader = new FileReader();
      
      reader.onload = (event) => {
        const photoData = event.target.result;
        currentPhotos.push(photoData);
        
        const photoItem = document.createElement('div');
        photoItem.className = 'photo-item';
        photoItem.style.position = 'relative';
        photoItem.style.display = 'inline-block';
        photoItem.style.margin = '5px';
        
        photoItem.innerHTML = `
          <img src="${photoData}" style="width: 80px; height: 80px; object-fit: cover; border-radius: 8px; border: 2px solid white;">
          <button class="removePhotoBtn" style="position: absolute; top: -5px; right: -5px; background: #ff4d4d; color: white; border: none; border-radius: 50%; width: 20px; height: 20px; font-size: 12px; cursor: pointer;">×</button>
        `;
        
        photoPreviewContainer.appendChild(photoItem);
        
        const removeBtn = photoItem.querySelector('.removePhotoBtn');
        removeBtn.addEventListener('click', () => {
          const index = currentPhotos.indexOf(photoData);
          if (index > -1) {
            currentPhotos.splice(index, 1);
          }
          photoItem.remove();
        });
      };
      
      reader.readAsDataURL(file);
    }
  }

  function updatePopupDateTime() {
    const now = new Date();
    noteDate.textContent = now.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
    noteTime.textContent = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
    popupCalendarDate = new Date(now);
  }

  function generatePopupCalendar(date) {
    const year = date.getFullYear();
    const month = date.getMonth();
    
    popupCalendarMonthYear.textContent = date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    
    popupCalendarGrid.innerHTML = '';
    
    const daysOfWeek = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
    daysOfWeek.forEach(day => {
      const dayElement = document.createElement('div');
      dayElement.className = 'calendar-day';
      dayElement.textContent = day;
      popupCalendarGrid.appendChild(dayElement);
    });
    
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDay = firstDay.getDay();
    
    for (let i = 0; i < startingDay; i++) {
      const emptyCell = document.createElement('div');
      emptyCell.className = 'calendar-date other-month';
      popupCalendarGrid.appendChild(emptyCell);
    }
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    for (let day = 1; day <= daysInMonth; day++) {
      const dateCell = document.createElement('div');
      dateCell.className = 'calendar-date';
      dateCell.textContent = day;
      
      const cellDate = new Date(year, month, day);
      cellDate.setHours(0, 0, 0, 0);
      
      if (cellDate.getTime() < today.getTime()) {
        dateCell.classList.add('disabled');
        dateCell.style.opacity = '0.5';
        dateCell.style.pointerEvents = 'none';
        dateCell.style.cursor = 'not-allowed';
      } else if (cellDate.getTime() === today.getTime()) {
        dateCell.classList.add('selected');
      }
      
      if (cellDate.getTime() >= today.getTime()) {
        dateCell.addEventListener('click', () => {
          popupCalendarDate = new Date(year, month, day);
          noteDate.textContent = popupCalendarDate.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
          popupCalendar.classList.remove('active');
          datePickerBtn.classList.remove('active');
        });
      }
      
      popupCalendarGrid.appendChild(dateCell);
    }
    
    const currentMonth = new Date();
    currentMonth.setHours(0, 0, 0, 0);
    
    if (date.getMonth() <= currentMonth.getMonth() && date.getFullYear() <= currentMonth.getFullYear()) {
      popupPrevMonthBtn.classList.add('disabled');
      popupPrevMonthBtn.style.opacity = '0.5';
      popupPrevMonthBtn.style.pointerEvents = 'none';
    } else {
      popupPrevMonthBtn.classList.remove('disabled');
      popupPrevMonthBtn.style.opacity = '1';
      popupPrevMonthBtn.style.pointerEvents = 'auto';
    }
  }

  popupPrevMonthBtn.addEventListener('click', () => {
    const currentMonth = new Date();
    currentMonth.setHours(0, 0, 0, 0);
    
    const prevMonth = new Date(popupCalendarDate);
    prevMonth.setMonth(prevMonth.getMonth() - 1);
    prevMonth.setHours(0, 0, 0, 0);
    
    if (prevMonth.getMonth() >= currentMonth.getMonth() && prevMonth.getFullYear() >= currentMonth.getFullYear()) {
      popupCalendarDate.setMonth(popupCalendarDate.getMonth() - 1);
      generatePopupCalendar(popupCalendarDate);
    }
  });

  function updatePopupDateTime() {
    const now = new Date();
    noteDate.textContent = now.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
    noteTime.textContent = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
    popupCalendarDate = new Date(now);
  }

  // Also update the outside click detection to be more precise:
document.addEventListener('click', (e) => {
  if (!moodPopup.contains(e.target) && e.target !== moodSelector && !moodSelector.contains(e.target)) {
    moodPopup.classList.remove('active');
  }
  
  if (!popupCalendar.contains(e.target) && e.target !== datePickerBtn && !datePickerBtn.contains(e.target)) {
    popupCalendar.classList.remove('active');
    datePickerBtn.classList.remove('active');
  }
});
}

function showSuccessMessage(message) {
  const messageElement = document.getElementById('successMessage');
  messageElement.textContent = message;
  messageElement.classList.add('show');
  
  setTimeout(() => {
    messageElement.classList.remove('show');
  }, 3000);
}

// ==========================
// ACHIEVEMENTS PAGE RENDERER
// ==========================
function renderAchievementsPage() {
  const grid = document.getElementById('achievementsGrid');
  const totalPoints = document.getElementById('totalPoints');
  const unlockedCount = document.getElementById('unlockedAchievements');
  const streakEmoji = document.getElementById('streakEmoji');
  const streakMessage = document.getElementById('streakMessage');
  const currentStreak = document.getElementById('currentStreak');
  const longestStreak = document.getElementById('longestStreak');
  
  // Update summary
  if (totalPoints) totalPoints.textContent = achievements.getTotalPoints();
  if (unlockedCount) unlockedCount.textContent = achievements.getUnlockedCount();
  if (streakEmoji) streakEmoji.textContent = streakManager.getStreakEmoji();
  if (streakMessage) streakMessage.textContent = streakManager.getMotivationalMessage();
  if (currentStreak) currentStreak.textContent = streakManager.currentStreak;
  if (longestStreak) longestStreak.textContent = streakManager.longestStreak;
  
  // Render achievements grid
  if (grid) {
    grid.innerHTML = '';
    
    Object.entries(achievements.achievements).forEach(([key, achievement]) => {
      const card = document.createElement('div');
      card.className = `achievement-card ${achievement.unlocked ? 'unlocked' : 'locked'}`;
      
      card.innerHTML = `
        <div class="achievement-header">
          <div class="achievement-card-icon">${achievement.icon}</div>
          <div class="achievement-card-info">
            <div class="achievement-card-title">${achievement.title}</div>
            <div class="achievement-card-desc">${achievement.desc}</div>
            <div class="achievement-card-points">${achievement.points} pts</div>
          </div>
        </div>
        <div class="achievement-progress">
          <div class="progress-bar">
            <div class="progress-fill" style="width: ${achievement.unlocked ? '100' : '0'}%"></div>
          </div>
          <div class="progress-text">${achievement.unlocked ? 'Unlocked!' : 'Locked'}</div>
        </div>
      `;
      
      grid.appendChild(card);
    });
  }
}

// ==========================
// GALLERY FUNCTIONALITY - WITH DATE GROUPING
// ==========================
const gallery = {
  photos: [],
  
  async loadPhotos() {
    try {
      const dateFilter = document.getElementById('dateFilter').value;
      const moodFilter = document.getElementById('moodFilter').value;
      this.photos = await fetchPhotos(dateFilter, moodFilter);
    } catch (error) {
      console.error('Error loading photos:', error);
      this.photos = [];
    }
  },
  
  setupFilters() {
    const dateFilter = document.getElementById('dateFilter');
    const moodFilter = document.getElementById('moodFilter');
    
    dateFilter.addEventListener('change', () => this.renderGallery());
    moodFilter.addEventListener('change', () => this.renderGallery());
  },
  
  async renderGallery() {
    const container = document.getElementById('galleryContainer');
    const noPhotos = document.getElementById('noPhotos');
    
    await this.loadPhotos();
    
    if (this.photos.length === 0) {
      container.innerHTML = '';
      noPhotos.style.display = 'block';
      return;
    }
    
    noPhotos.style.display = 'none';
    container.innerHTML = '';
    
    // Group photos by date
    const photosByDate = this.groupPhotosByDate(this.photos);
    
    // Create date sections
    Object.keys(photosByDate).sort((a, b) => new Date(b) - new Date(a)).forEach(date => {
      const dateSection = this.createDateSection(date, photosByDate[date]);
      container.appendChild(dateSection);
    });
  },
  
  groupPhotosByDate(photos) {
    const grouped = {};
    
    photos.forEach(photo => {
      const photoDate = new Date(photo.date);
      const dateKey = photoDate.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
      });
      
      if (!grouped[dateKey]) {
        grouped[dateKey] = [];
      }
      grouped[dateKey].push(photo);
    });
    
    return grouped;
  },
  
  createDateSection(date, photos) {
    const dateSection = document.createElement('div');
    dateSection.className = 'date-section';
    
    const dateHeader = document.createElement('div');
    dateHeader.className = 'date-header';
    dateHeader.textContent = date;
    
    const photosRow = document.createElement('div');
    photosRow.className = 'photos-row';
    
    // Sort photos by time (newest first)
    photos.sort((a, b) => new Date(b.date) - new Date(a.date));
    
    photos.forEach(photo => {
      const photoItem = this.createPhotoItem(photo);
      photosRow.appendChild(photoItem);
    });
    
    dateSection.appendChild(dateHeader);
    dateSection.appendChild(photosRow);
    
    return dateSection;
  },
  
  createPhotoItem(photo) {
    const photoItem = document.createElement('div');
    photoItem.className = 'photo-item-gallery';
    
    const photoDate = new Date(photo.date);
    const timeString = photoDate.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
    
    photoItem.innerHTML = `
      <img src="${photo.src}" class="photo-thumbnail-gallery" alt="Journal photo">
      <div class="photo-overlay">
        <span class="photo-mood-gallery">${photo.mood}</span>
        <span class="photo-time-gallery">${timeString}</span>
      </div>
      <button class="delete-photo-btn-gallery" data-note-id="${photo.note_id}" title="Delete photo">×</button>
    `;
    
    // Add click event to open modal
    photoItem.addEventListener('click', (e) => {
      if (!e.target.classList.contains('delete-photo-btn-gallery')) {
        this.openPhotoModal(photo.src, photo.mood, photo.date, photo.text);
      }
    });
    
    return photoItem;
  },
  
  openPhotoModal(src, mood, date, text) {
  const modal = document.getElementById('photoModal');
  const modalImage = document.getElementById('modalImage');
  const modalMood = document.getElementById('modalMood');
  const modalMoodText = document.getElementById('modalMoodText');
  const modalDate = document.getElementById('modalDate');
  const modalNote = document.getElementById('modalNote');
  const closeModal = document.getElementById('closeModal');
  
  modalImage.src = src;
  modalMood.textContent = mood;
  modalMoodText.textContent = moodMap[mood] || 'No mood';
  
  const dateObj = new Date(date);
  modalDate.textContent = dateObj.toLocaleDateString('en-US', { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit'
  });
  
  modalNote.textContent = text || 'No description';
  
  // Use the correct method to show the modal
  modal.classList.add('active');
  modal.style.display = 'flex'; // Ensure it uses flex display
  
  closeModal.onclick = () => {
    modal.classList.remove('active');
    modal.style.display = 'none';
  };
  
  window.onclick = (e) => {
    if (e.target === modal) {
      modal.classList.remove('active');
      modal.style.display = 'none';
    }
  };
}
};

// Add these functions to your JavaScript
function downloadPhoto() {
  const modalImage = document.getElementById('modalImage');
  const link = document.createElement('a');
  link.download = `journal-photo-${new Date().toISOString().split('T')[0]}.jpg`;
  link.href = modalImage.src;
  link.click();
  showSuccessMessage('Photo download started!');
}

async function sharePhoto() {
  const modalImage = document.getElementById('modalImage');
  
  if (navigator.share) {
    try {
      // Convert data URL to blob for sharing
      const response = await fetch(modalImage.src);
      const blob = await response.blob();
      const file = new File([blob], 'journal-photo.jpg', { type: 'image/jpeg' });
      
      await navigator.share({
        files: [file],
        title: 'My Journal Photo',
        text: 'Check out this photo from my journal!'
      });
    } catch (error) {
      console.log('Sharing cancelled or failed:', error);
    }
  } else {
    // Fallback: copy image URL to clipboard
    try {
      await navigator.clipboard.writeText(modalImage.src);
      showSuccessMessage('Photo URL copied to clipboard!');
    } catch (error) {
      alert('Sharing is not supported in your browser. You can right-click the image to copy it.');
    }
  }
}

function initializeGallery() {
  gallery.setupFilters();
}

// ==========================
// CALENDAR FUNCTIONALITY
// ==========================
const calendar = {
  currentDate: new Date(),
  
  initialize() {
    this.setupNavigation();
    this.renderCalendar();
  },
  
  setupNavigation() {
    const prevYearBtn = document.getElementById('prevYear');
    const prevMonthBtn = document.getElementById('prevMonthCal');
    const nextMonthBtn = document.getElementById('nextMonthCal');
    const nextYearBtn = document.getElementById('nextYear');
    
    if (prevYearBtn) {
      prevYearBtn.addEventListener('click', () => {
        this.currentDate.setFullYear(this.currentDate.getFullYear() - 1);
        this.renderCalendar();
      });
    }
    
    if (prevMonthBtn) {
      prevMonthBtn.addEventListener('click', () => {
        this.currentDate.setMonth(this.currentDate.getMonth() - 1);
        this.renderCalendar();
      });
    }
    
    if (nextMonthBtn) {
      nextMonthBtn.addEventListener('click', () => {
        this.currentDate.setMonth(this.currentDate.getMonth() + 1);
        this.renderCalendar();
      });
    }
    
    if (nextYearBtn) {
      nextYearBtn.addEventListener('click', () => {
        this.currentDate.setFullYear(this.currentDate.getFullYear() + 1);
        this.renderCalendar();
      });
    }
  },
  
  async renderCalendar() {
    const calendarGrid = document.getElementById('calendarGrid');
    const currentMonthYear = document.getElementById('currentMonthYear');
    
    if (!calendarGrid || !currentMonthYear) {
      console.error('Calendar elements not found');
      return;
    }
    
    const year = this.currentDate.getFullYear();
    const month = this.currentDate.getMonth();
    
    currentMonthYear.textContent = this.currentDate.toLocaleDateString('en-US', { 
      month: 'long', 
      year: 'numeric' 
    });
    
    calendarGrid.innerHTML = '';
    
    const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    daysOfWeek.forEach(day => {
      const dayHeader = document.createElement('div');
      dayHeader.className = 'calendar-day-header';
      dayHeader.textContent = day;
      calendarGrid.appendChild(dayHeader);
    });
    
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDay = firstDay.getDay();
    
    for (let i = 0; i < startingDay; i++) {
      const emptyCell = document.createElement('div');
      emptyCell.className = 'calendar-day other-month';
      calendarGrid.appendChild(emptyCell);
    }
    
    try {
      const response = await fetch(`${API_BASE}/calendar/${year}/${month + 1}`);
      if (!response.ok) throw new Error('Failed to fetch calendar data');
      const calendarData = await response.json();
      
      for (let day = 1; day <= daysInMonth; day++) {
        const dayCell = document.createElement('div');
        dayCell.className = 'calendar-day';
        
        const cellDate = new Date(year, month, day);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        cellDate.setHours(0, 0, 0, 0);
        
        const dateString = formatDateForAPI(cellDate);
        let dayNotes = [];
        
        if (Array.isArray(calendarData)) {
          const dayData = calendarData.find(d => d.date === dateString);
          dayNotes = dayData ? dayData.notes || [] : [];
        } else if (calendarData[dateString]) {
          dayNotes = calendarData[dateString].notes || [];
        }
        
        // Filter out deleted notes
        dayNotes = dayNotes.filter(note => !note.deleted);
        
        const dayNumber = document.createElement('div');
        dayNumber.className = 'day-number';
        dayNumber.textContent = day;
        
        if (cellDate.getTime() === today.getTime()) {
          dayCell.classList.add('today');
        }
        
        dayCell.appendChild(dayNumber);
        
        if (dayNotes.length > 0) {
  const moodCounts = {};
  dayNotes.forEach(note => {
    moodCounts[note.mood] = (moodCounts[note.mood] || 0) + 1;
  });
  
  const dominantMood = Object.keys(moodCounts).reduce((a, b) => 
    moodCounts[a] > moodCounts[b] ? a : b
  );
  
  // Add mood class based on the dominant mood with new color scheme
  switch (dominantMood) {
    case '😊': dayCell.classList.add('mood-happy'); break;      // Green
    case '🙂': dayCell.classList.add('mood-content'); break;   // Purple
    case '😐': dayCell.classList.add('mood-neutral'); break;   // Yellow
    case '🙁': dayCell.classList.add('mood-sad'); break;       // Blue
    case '😣': dayCell.classList.add('mood-stressed'); break;  // Red
  }

  // ADD THIS: Show the dominant mood emoji instead of text preview
  const moodElement = document.createElement('div');
  moodElement.className = 'day-mood';
  moodElement.textContent = dominantMood;
  dayCell.appendChild(moodElement);
}
        
        dayCell.addEventListener('click', () => {
          this.showDayNotes(cellDate, dayNotes);
        });
        
        calendarGrid.appendChild(dayCell);
      }
      
      const totalCells = 42;
      const currentCells = startingDay + daysInMonth;
      const remainingCells = totalCells - currentCells;
      
      for (let i = 0; i < remainingCells; i++) {
        const emptyCell = document.createElement('div');
        emptyCell.className = 'calendar-day other-month';
        calendarGrid.appendChild(emptyCell);
      }
      
    } catch (error) {
      console.error('Error rendering calendar:', error);
      this.renderCalendarFallback(calendarGrid, year, month, daysInMonth, startingDay);
    }
  },

  renderCalendarFallback(calendarGrid, year, month, daysInMonth, startingDay) {
    for (let day = 1; day <= daysInMonth; day++) {
      const dayCell = document.createElement('div');
      dayCell.className = 'calendar-day';
      
      const cellDate = new Date(year, month, day);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      cellDate.setHours(0, 0, 0, 0);
      
      if (cellDate.getTime() === today.getTime()) {
        dayCell.classList.add('today');
      }
      
      const dayNumber = document.createElement('div');
      dayNumber.className = 'day-number';
      dayNumber.textContent = day;
      dayCell.appendChild(dayNumber);
      
      dayCell.addEventListener('click', () => {
        this.showDayNotes(cellDate, []);
      });
      
      calendarGrid.appendChild(dayCell);
    }
    
    const totalCells = 42;
    const currentCells = startingDay + daysInMonth;
    const remainingCells = totalCells - currentCells;
    
    for (let i = 0; i < remainingCells; i++) {
      const emptyCell = document.createElement('div');
      emptyCell.className = 'calendar-day other-month';
      calendarGrid.appendChild(emptyCell);
    }
  },
  
  async showDayNotes(date, notes) {
    const modal = document.getElementById('dayModal');
    const modalDateTitle = document.getElementById('modalDateTitle');
    const dayNotes = document.getElementById('dayNotes');
    const closeModal = document.getElementById('closeDayModal');
    
    if (!modal || !modalDateTitle || !dayNotes) {
      console.error('Day modal elements not found');
      return;
    }
    
    modalDateTitle.textContent = date.toLocaleDateString('en-US', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
    
    dayNotes.innerHTML = '';
    
    if (notes.length === 0) {
      try {
        const dateString = formatDateForAPI(date);
        notes = await fetchNotes(dateString);
      } catch (error) {
        console.error('Error fetching day notes:', error);
      }
    }
    
    if (notes.length === 0) {
      dayNotes.innerHTML = `
        <div class="no-notes">
          <div class="no-notes-icon">📝</div>
          <div>No entries for this day</div>
        </div>
      `;
    } else {
      notes.sort((a, b) => new Date(b.date) - new Date(a.date));
      
      notes.forEach((note, index) => {
        setTimeout(() => {
          const noteItem = document.createElement('div');
          noteItem.className = 'note-item';
          
          const noteDate = new Date(note.date);
          const timeString = noteDate.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
          
          noteItem.innerHTML = `
            <div class="note-header">
              <div class="mood-time-container">
                <div class="note-mood">${note.mood || ''}</div>
                <div class="note-time">${timeString}</div>
              </div>
            </div>
            <div class="note-content">
              ${note.title ? `<div class="note-title" style="font-size: 18px; font-weight: bold; color: var(--accent-light); margin-bottom: 10px;">${note.title}</div>` : ''}
              ${note.photos && note.photos.length > 0 ? `
                <div class="note-photos">
                  ${note.photos.map(photo => `
                    <img src="${photo}" class="note-photo" 
                        onclick="gallery.openPhotoModal('${photo}', '${note.mood || ''}', '${note.date}', '${note.text.replace(/'/g, "\\'")}')">
                  `).join('')}
                </div>
              ` : ''}
              <div class="note-text">${note.text || ''}</div>
            </div>
            <button class="delete-note-btn" data-note-id="${note.id}">Delete</button>
          `;
          
          dayNotes.appendChild(noteItem);
          
          const deleteBtn = noteItem.querySelector('.delete-note-btn');
          if (deleteBtn) {
            deleteBtn.addEventListener('click', async (e) => {
              e.stopPropagation();
              if (confirm('Are you sure you want to delete this note?')) {
                try {
                  await deleteNote(note.id);
                  showSuccessMessage('Note moved to trash!');
                  modal.style.display = 'none';
                  this.renderCalendar();
                } catch (error) {
                  alert('Failed to delete note. Please try again.');
                }
              }
            });
          }
        }, index * 100);
      });
    }
    
    modal.classList.add('active');
    modal.style.display = 'flex';
    
    if (closeModal) {
    closeModal.onclick = () => {
    modal.classList.remove('active');
    modal.style.display = 'none';
  };
}

    window.onclick = (e) => {
    if (e.target === modal) {
    modal.classList.remove('active');
    modal.style.display = 'none';
  }
};
  }
};

function initializeCalendar() {
  calendar.initialize();
}

// ==========================
// TRASH BIN FUNCTIONALITY
// ==========================
const trashBin = {
  async loadTrash() {
    try {
      const response = await fetch(`${API_BASE}/trash`);
      if (!response.ok) throw new Error('Failed to fetch trash');
      return await response.json();
    } catch (error) {
      console.error('Error loading trash:', error);
      return [];
    }
  },
  
  async renderTrash() {
    const container = document.getElementById('trashContainer');
    const noTrash = document.getElementById('noTrash');
    
    const deletedNotes = await this.loadTrash();
    
    if (deletedNotes.length === 0) {
      container.innerHTML = '';
      noTrash.style.display = 'block';
      return;
    }
    
    noTrash.style.display = 'none';
    container.innerHTML = '';
    
    // Sort notes by deletion date (newest first)
    deletedNotes.sort((a, b) => new Date(b.date) - new Date(a.date));
    
    // Create trash items with animation
    deletedNotes.forEach((note, index) => {
      setTimeout(() => {
        const trashItem = this.createTrashItem(note);
        container.appendChild(trashItem);
        
        // Add appear animation
        setTimeout(() => {
          trashItem.classList.add('appear');
        }, 50);
      }, index * 100); // Stagger animation
    });
  },
  
  createTrashItem(note) {
    const item = document.createElement('div');
    item.className = 'trash-item';
    
    const noteDate = new Date(note.date);
    const dateString = noteDate.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric', 
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit'
    });
    
    item.innerHTML = `
      <div class="trash-item-header">
        <div class="trash-mood-time">
          <span class="trash-mood">${note.mood}</span>
          <span class="trash-date">${dateString}</span>
        </div>
        <div class="trash-actions">
          <button class="restore-btn" data-note-id="${note.id}">Restore</button>
          <button class="permanent-delete-btn" data-note-id="${note.id}">Delete Permanently</button>
        </div>
      </div>
      ${note.title ? `<div class="trash-title">${note.title}</div>` : ''}
      <div class="trash-text">${note.text}</div>
      ${note.photos && note.photos.length > 0 ? `
        <div class="trash-photos">
          ${note.photos.map(photo => `
            <img src="${photo}" class="trash-photo" 
                 onclick="gallery.openPhotoModal('${photo}', '${note.mood}', '${note.date}', '${note.text.replace(/'/g, "\\'")}')">
          `).join('')}
        </div>
      ` : ''}
    `;
    
    // Add event listeners
    const restoreBtn = item.querySelector('.restore-btn');
    restoreBtn.addEventListener('click', async () => {
      await this.restoreNote(note.id);
    });
    
    const deleteBtn = item.querySelector('.permanent-delete-btn');
    deleteBtn.addEventListener('click', async () => {
      if (confirm('Are you sure you want to permanently delete this note? This action cannot be undone.')) {
        await this.permanentlyDelete(note.id);
      }
    });
    
    return item;
  },
  
  async restoreNote(noteId) {
    try {
      const response = await fetch(`${API_BASE}/trash/${noteId}/restore`, {
        method: 'POST'
      });
      
      if (!response.ok) throw new Error('Failed to restore note');
      
      showSuccessMessage('Note restored successfully!');
      this.renderTrash();
      
      // Refresh current page if it's home
      if (currentPage === 'home') {
        renderNotesForDate(currentDate);
      }
    } catch (error) {
      alert('Failed to restore note. Please try again.');
    }
  },
  
  async permanentlyDelete(noteId) {
    try {
      const response = await fetch(`${API_BASE}/trash/${noteId}`, {
        method: 'DELETE'
      });
      
      if (!response.ok) throw new Error('Failed to delete note');
      
      showSuccessMessage('Note permanently deleted!');
      this.renderTrash();
    } catch (error) {
      alert('Failed to delete note. Please try again.');
    }
  },
  
  async emptyTrash() {
    if (confirm('Are you sure you want to empty the trash? This will permanently delete all notes in the trash and cannot be undone.')) {
      const deletedNotes = await this.loadTrash();
      let successCount = 0;
      
      for (const note of deletedNotes) {
        try {
          await this.permanentlyDelete(note.id);
          successCount++;
        } catch (error) {
          console.error(`Failed to delete note ${note.id}:`, error);
        }
      }
      
      showSuccessMessage(`Successfully deleted ${successCount} notes from trash!`);
      this.renderTrash();
    }
  }
};

function initializeTrashBin() {
  const emptyTrashBtn = document.getElementById('emptyTrashBtn');
  if (emptyTrashBtn) {
    emptyTrashBtn.addEventListener('click', () => {
      trashBin.emptyTrash();
    });
  }
}

// ==========================
// DEVELOPER MODAL FUNCTIONALITY
// ==========================
function initializeDeveloperModal() {
  const developerBtn = document.getElementById('developerBtn');
  const developerModal = document.getElementById('developerModal');
  const closeDeveloperModal = document.getElementById('closeDeveloperModal');

  if (developerBtn && developerModal) {
    developerBtn.addEventListener('click', () => {
      developerModal.classList.add('active');
      developerModal.style.display = 'flex';
    });

    closeDeveloperModal.addEventListener('click', () => {
      developerModal.classList.remove('active');
      developerModal.style.display = 'none';
    });

    // Close modal when clicking outside
    window.addEventListener('click', (e) => {
      if (e.target === developerModal) {
        developerModal.classList.remove('active');
        developerModal.style.display = 'none';
      }
    });
  }
}

// Run this in console to reset everything
// localStorage.removeItem('journal-achievements');
// localStorage.removeItem('journal-streak');
// localStorage.removeItem('journal-theme');
// location.reload();